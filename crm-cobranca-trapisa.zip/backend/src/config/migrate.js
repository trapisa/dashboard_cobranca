const fs = require('fs');
const path = require('path');
const { pool } = require('./db');

async function migrate() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  console.log('Aplicando schema no banco de dados...');
  try {
    await pool.query(schema);
    console.log('Migração concluída com sucesso.');
  } catch (err) {
    console.error('Erro ao aplicar migração:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

migrate();
